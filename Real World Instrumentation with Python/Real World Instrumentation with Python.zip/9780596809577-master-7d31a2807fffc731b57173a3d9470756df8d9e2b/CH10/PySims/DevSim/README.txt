README.txt (for DevSim)
================================================================================
This file is part of the source code provided with the book "Real-World
Instrumentation Using Python" by J. M. Hughes, published by O'Reilly Media,
December 2010, ISBN 978-0-596-80956-0.
================================================================================

To import DevSim from this directory and still have access to the Lib directory,
enter the following after launching Python:

import sys
sys.path.append('..')
import DevSim

You will now be able to access DevSim's methods from the Python command line.
